"""Tiny client for the Bank of Canada Valet API (public, no key).

Docs: https://www.bankofcanada.ca/valet/docs
Example series:
    V41690973  Total CPI, index 2002=100, not seasonally adjusted (monthly)
    V41690914  CPI, seasonally adjusted (monthly)

Data is cached to ai-econ-lab/data/<series>.csv so you only download once.
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd
import requests

VALET = "https://www.bankofcanada.ca/valet/observations/{series}/json"
DATA_DIR = Path(__file__).resolve().parents[1] / "data"


def get_series(series: str, start: str = "1995-01-01", refresh: bool = False) -> pd.Series:
    """Return a monthly pd.Series (DatetimeIndex, float values) for a Valet series."""
    DATA_DIR.mkdir(exist_ok=True)
    cache = DATA_DIR / f"{series}.csv"
    if cache.exists() and not refresh:
        s = pd.read_csv(cache, index_col=0, parse_dates=True).iloc[:, 0]
    else:
        r = requests.get(VALET.format(series=series), params={"start_date": start}, timeout=30)
        r.raise_for_status()
        obs = r.json()["observations"]
        s = pd.Series(
            {pd.Timestamp(o["d"]): float(o[series]["v"]) for o in obs if o.get(series, {}).get("v")},
            name=series,
        )
        s.to_frame().to_csv(cache)
    s = s.sort_index().astype(float)
    s.index = pd.DatetimeIndex(s.index).to_period("M").to_timestamp()  # month-start
    s.name = series
    return s
